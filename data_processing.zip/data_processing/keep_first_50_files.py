import os
import argparse

def keep_first_50_files(folder_path):
    # List all files (exclude subdirectories)
    files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
    
    # Sort files alphabetically
    files.sort()
    
    # Determine files to remove
    files_to_remove = files[15:]
    
    for file_name in files_to_remove:
        file_path = os.path.join(folder_path, file_name)
        os.remove(file_path)
        print(f"Removed: {file_path}")

def main():
    parser = argparse.ArgumentParser(description="Keep only the first 50 files in a folder (sorted by name).")
    parser.add_argument("--folder", type=str, help="Path to the folder")

    args = parser.parse_args()
    keep_first_50_files(args.folder)

if __name__ == "__main__":
    main()
