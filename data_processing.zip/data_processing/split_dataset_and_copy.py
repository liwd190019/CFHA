# Here’s a Python script that will split the 30 YOLO images and labels in 
# /scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal-30 into 20 for training and 10 for validation, 
# copying both images and labels into corresponding subfolders.
import os
import shutil
import random

# Source directories
src_images = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal-30/images"
src_labels = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal-30/labels"

# Destination directories
train_images = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/manipal_update3_removal/train/images"
train_labels = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/manipal_update3_removal/train/labels"

val_images = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/manipal_update3_removal/val/images"
val_labels = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/manipal_update3_removal/val/labels"

# Create destination directories if not exist
for d in [train_images, train_labels, val_images, val_labels]:
    os.makedirs(d, exist_ok=True)

# Get all image filenames
image_files = [f for f in os.listdir(src_images) if f.lower().endswith(('.jpg', '.png', '.jpeg'))]
image_files.sort()
random.seed(42)  # for reproducibility
random.shuffle(image_files)

# Split into train and val
train_files = image_files[:20]
val_files = image_files[20:]

def copy_files(file_list, src_img, src_lbl, dst_img, dst_lbl):
    for f in file_list:
        img_src = os.path.join(src_img, f)
        lbl_src = os.path.join(src_lbl, os.path.splitext(f)[0] + ".txt")
        img_dst = os.path.join(dst_img, f)
        lbl_dst = os.path.join(dst_lbl, os.path.splitext(f)[0] + ".txt")

        if os.path.exists(img_src):
            shutil.copy(img_src, img_dst)
        if os.path.exists(lbl_src):
            shutil.copy(lbl_src, lbl_dst)

# Copy train and val files
copy_files(train_files, src_images, src_labels, train_images, train_labels)
copy_files(val_files, src_images, src_labels, val_images, val_labels)

print(f"Copied {len(train_files)} images to train and {len(val_files)} images to val.")
