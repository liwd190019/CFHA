#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Paste kept people (from the original image) back onto a people-removed image,
using a black/white kept mask (white=kept, black=removed), assuming all images
have the same size.

Inputs per <base>:
  - original image:   <orig_dir>/<base>.<ext>
  - removed image:    <removed_dir>/<base>.<ext>   (same size; people already removed)
  - kept mask (B/W):  <mask_dir>/<base>_mask.png   (255=kept, 0=removed)

Output:
  - composited image: <output_dir>/<base>.png

Optional:
  - Feathering (Gaussian blur on the mask) to reduce edges.
  - Morphological open/close (on the mask) to clean specks / fill small holes.

Example:
  python paste_kept_people.py \
      --orig_dir data/orig \
      --removed_dir data/removed \
      --mask_dir data/kept_masks_stage4 \
      --output_dir data/pasted \
      --feather 3 \
      --open_iter 1 \
      --close_iter 1
"""

import os
import argparse
from typing import Tuple

import numpy as np
from PIL import Image
from tqdm import tqdm
import cv2

IMG_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff")

def load_rgb(path: str) -> np.ndarray:
    """Load an image as HxWx3 uint8 (RGB)."""
    im = Image.open(path).convert("RGB")
    return np.array(im, dtype=np.uint8)

def load_mask(path: str) -> np.ndarray:
    """Load a B/W mask as HxW uint8 (0..255)."""
    m = Image.open(path).convert("L")
    return np.array(m, dtype=np.uint8)

def find_image_path(folder: str, base: str) -> str:
    for ext in IMG_EXTS:
        p = os.path.join(folder, base + ext)
        print(f'base: {base}')
        print(f'p: {p}')
        if os.path.exists(p):
            print('p exists')
            return p
    print(f"p doesn't exist.")
    return None

def prepare_alpha(mask_bw: np.ndarray,
                  feather: int = 0,
                  open_iter: int = 0,
                  close_iter: int = 0) -> np.ndarray:
    """
    Turn a 0/255 mask into a float alpha in [0,1], with optional morphology and feathering.
    - open_iter: remove tiny specks (erode then dilate)
    - close_iter: fill tiny holes (dilate then erode)
    - feather: Gaussian blur radius (pixels) for softer edges
    """
    mask = mask_bw.copy()

    # Morphology (on 0/255 mask)
    if open_iter > 0:
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=open_iter)
    if close_iter > 0:
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=close_iter)

    # Feather (anti-aliased edges)
    if feather > 0:
        # Convert to [0,1] before blur
        a = (mask.astype(np.float32) / 255.0)
        # Use an odd kernel size ~ 6*sigma+1; here we use feather as sigma
        k = max(3, int(6 * feather) | 1)  # ensure odd
        a = cv2.GaussianBlur(a, (k, k), sigmaX=feather, sigmaY=feather, borderType=cv2.BORDER_REFLECT101)
        a = np.clip(a, 0.0, 1.0)
        return a
    else:
        return (mask.astype(np.float32) / 255.0)

def composite(original: np.ndarray, removed: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """
    Composite original onto removed using alpha:
      out = removed * (1 - alpha) + original * alpha
    original, removed: HxWx3 uint8
    alpha: HxW float32 in [0,1]
    """
    if original.shape != removed.shape:
        raise ValueError(f"Size mismatch: original {original.shape} vs removed {removed.shape}")
    if alpha.shape[:2] != original.shape[:2]:
        raise ValueError(f"Alpha size {alpha.shape} does not match image {original.shape}")

    # Expand alpha to 3 channels
    a3 = np.expand_dims(alpha, axis=2)  # HxWx1
    out = removed.astype(np.float32) * (1.0 - a3) + original.astype(np.float32) * a3
    return np.clip(out, 0, 255).astype(np.uint8)

def process_all(orig_dir: str,
                removed_dir: str,
                mask_dir: str,
                output_dir: str,
                feather: int,
                open_iter: int,
                close_iter: int):
    os.makedirs(output_dir, exist_ok=True)

    # Build set of bases from the kept mask folder (authoritative)
    bases = []
    for fname in sorted(os.listdir(mask_dir)):
        if fname.endswith("_mask.png"):
            bases.append(fname[:-9])  # strip "_mask.png"
    if not bases:
        print("[WARN] No *_mask.png files found in mask_dir")

    for base in tqdm(bases, desc="Pasting kept people"):
        orig_path = find_image_path(orig_dir, base)
        rem_path  = find_image_path(removed_dir, base)
        mask_path = os.path.join(mask_dir, base + "_mask.png")

        if orig_path is None:
            print(f"[WARN] Original image missing for {base}")
            continue
        if rem_path is None:
            print(f"[WARN] Removed image missing for {base}")
            continue
        if not os.path.exists(mask_path):
            print(f"[WARN] Mask missing for {base}")
            continue

        orig = load_rgb(orig_path)
        rem  = load_rgb(rem_path)
        m_bw = load_mask(mask_path)

        if orig.shape[:2] != rem.shape[:2] or orig.shape[:2] != m_bw.shape[:2]:
            print(f"[WARN] Size mismatch for {base}: orig {orig.shape}, removed {rem.shape}, mask {m_bw.shape}")
            continue

        alpha = prepare_alpha(m_bw, feather=feather, open_iter=open_iter, close_iter=close_iter)
        out = composite(orig, rem, alpha)

        out_path = os.path.join(output_dir, base + ".png")
        Image.fromarray(out).save(out_path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--orig_dir", required=True, help="Directory with original images (with people)")
    ap.add_argument("--removed_dir", required=True, help="Directory with people-removed images (same size)")
    ap.add_argument("--mask_dir", required=True, help="Directory with kept B/W masks from Stage-4 (white=kept)")
    ap.add_argument("--output_dir", required=True, help="Directory to save composited outputs")
    ap.add_argument("--feather", type=int, default=2, help="Gaussian feather radius (pixels). 0 = no feather")
    ap.add_argument("--open_iter", type=int, default=0, help="Morphology OPEN iterations on mask (remove specks)")
    ap.add_argument("--close_iter", type=int, default=0, help="Morphology CLOSE iterations on mask (fill tiny holes)")
    args = ap.parse_args()

    process_all(args.orig_dir, args.removed_dir, args.mask_dir, args.output_dir,
                feather=args.feather, open_iter=args.open_iter, close_iter=args.close_iter)

if __name__ == "__main__":
    main()
