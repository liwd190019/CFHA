#!/usr/bin/env python
import os, json, argparse
from collections import defaultdict
import torch
import torch.nn.functional as F
import open_clip
import numpy as np
import networkx as nx
import cv2
from PIL import Image
from tqdm import tqdm

# ---------- config ----------
IMG_EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")

# --- Helper: find original image by base name ---
def find_image_path(images_dir, base):
    for ext in IMG_EXTS:
        p = os.path.join(images_dir, base + ext)
        print(f'p = {p}')
        if os.path.exists(p):
            print(f'this p exists')
            return p
    print(f"this p doesn't exist")
    return None

# --- Helper: YOLO to pixel bbox ---
def yolo_to_pixel_bbox(yolo_box, img_w, img_h):
    x_c, y_c, w, h = yolo_box
    x_c *= img_w
    y_c *= img_h
    w *= img_w
    h *= img_h
    x0 = max(int(round(x_c - w / 2)), 0)
    y0 = max(int(round(y_c - h / 2)), 0)
    x1 = min(int(round(x_c + w / 2)), img_w)
    y1 = min(int(round(y_c + h / 2)), img_h)
    return x0, y0, x1, y1

# --- Helper: box overlap + graph clustering ---
def boxes_touch_or_overlap(b1, b2, pad=1):
    x0a, y0a, x1a, y1a = b1
    x0b, y0b, x1b, y1b = b2
    x0a, y0a, x1a, y1a = x0a - pad, y0a - pad, x1a + pad, y1a + pad
    x0b, y0b, x1b, y1b = x0b - pad, y0b - pad, x1b + pad, y1b + pad
    return not (x1a < x0b or x1b < x0a or y1a < y0b or y1b < y0a)

def cluster_humans(mask_bin, bboxes):
    H, W = mask_bin.shape
    masks = []
    for (x0, y0, x1, y1) in bboxes:
        m = np.zeros((H, W), np.uint8)
        m[y0:y1, x0:x1] = (mask_bin[y0:y1, x0:x1] > 0).astype(np.uint8)
        masks.append(m)

    G = nx.Graph()
    G.add_nodes_from(range(len(bboxes)))
    kernel = np.ones((3, 3), np.uint8)
    for i in range(len(bboxes)):
        for j in range(i + 1, len(bboxes)):
            if not boxes_touch_or_overlap(bboxes[i], bboxes[j]):
                continue
            if np.any(cv2.dilate(masks[i], kernel) & masks[j]):
                G.add_edge(i, j)

    clusters = list(nx.connected_components(G))
    cluster_id_map = {}
    for cid, group in enumerate(clusters):
        for idx in group:
            cluster_id_map[idx] = cid
    return cluster_id_map

# --- Load learned reference (.pt) ---
def load_learned_ref(ref_path, device):
    ref = torch.load(ref_path, map_location="cpu")
    t_star = ref["t_star"].to(device)
    t_anchor = ref.get("t_anchor", None)
    if t_anchor is not None:
        t_anchor = t_anchor.to(device)

    model, _, preprocess = open_clip.create_model_and_transforms(
        ref["model"], pretrained=ref["pretrained"]
    )
    model.eval().to(device)
    return model, preprocess, t_star, t_anchor, bool(ref.get("tta_flip", False))

# --- NEW: Batched CLIP scoring ---
@torch.no_grad()
def score_patches_batch(model, preprocess, crops, t_star,
                        t_anchor=None, tta_flip=False,
                        device="cuda", batch_size=64):
    scores = [None] * len(crops)
    for i in range(0, len(crops), batch_size):
        batch = crops[i:i + batch_size]
        imgs = torch.stack([preprocess(p) for p in batch]).to(device)

        feats = model.encode_image(imgs)
        if tta_flip:
            flips = torch.stack([preprocess(p.transpose(Image.FLIP_LEFT_RIGHT)) for p in batch]).to(device)
            feats = 0.5 * (feats + model.encode_image(flips))

        feats = F.normalize(feats, dim=-1)
        s = torch.clamp((feats @ t_star), -1, 1).cpu().tolist()

        scores[i:i + batch_size] = s
    return scores

# --- Main conversion logic ---
def convert(args):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess, t_star, t_anchor, tta_flip = load_learned_ref(args.ref, device)

    os.makedirs(args.output_dir, exist_ok=True)
    label_files = sorted([f for f in os.listdir(args.labels_dir) if f.endswith(".txt")])

    for fname in tqdm(label_files, desc='Processing files'):
        # if 'step' not in fname or 'image' not in fname: continue

        base = os.path.splitext(fname)[0]
        print(f'base = {base}')
        label_path = os.path.join(args.labels_dir, fname)
        mask_path = os.path.join(args.masks_dir, base + "_mask.png")
        img_path = find_image_path(args.images_dir, base)

        if img_path is None:
            print(f"[WARN] Image missing for {base}")
            continue
        if not os.path.exists(mask_path):
            print(f"[WARN] Mask missing for {base}")
            continue

        orig_pil = Image.open(img_path).convert("RGB")
        W, H = orig_pil.size

        rgb_mask = np.array(Image.open(mask_path).convert("RGB"))
        bin_mask = (np.any(rgb_mask != [0, 0, 0], axis=2).astype(np.uint8) * 255)

        yolo_anns = []
        with open(label_path) as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) != 5:
                    continue
                cls, x, y, w, h = map(float, parts)
                yolo_anns.append((cls, x, y, w, h))
        if not yolo_anns:
            continue

        pixel_bboxes = [yolo_to_pixel_bbox((x, y, w, h), W, H) for (cls, x, y, w, h) in yolo_anns]
        cluster_map = cluster_humans(bin_mask, pixel_bboxes)

        crops, valid_idx = [], []
        for idx, (cls, x, y, w, h) in enumerate(yolo_anns):
            x0, y0, x1, y1 = pixel_bboxes[idx]
            if x1 <= x0 or y1 <= y0:
                continue
            crops.append(orig_pil.crop((x0, y0, x1, y1)))
            valid_idx.append(idx)

        batch_scores = score_patches_batch(model, preprocess, crops,
                                           t_star, t_anchor, tta_flip,
                                           device=device,
                                           batch_size=args.batch_size)
        scores = {i: s for i, s in zip(valid_idx, batch_scores)}

        objects = []
        for idx, (cls, x, y, w, h) in enumerate(yolo_anns):
            cid = cluster_map.get(idx, -1)
            objects.append({
                "id": idx,
                "class": int(cls),
                "bbox": [float(x), float(y), float(w), float(h)],
                "cluster_id": int(cid),
                "clip_score": (None if scores.get(idx) is None else float(scores[idx]))
            })

        out_json = {"image_id": base, "objects": objects}
        with open(os.path.join(args.output_dir, base + ".json"), "w") as f:
            json.dump(out_json, f, indent=2)

# --- CLI ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--labels_dir", required=True, help="Directory of YOLO .txt files")
    parser.add_argument("--masks_dir", required=True, help="Directory of RGB instance masks")
    parser.add_argument("--images_dir", required=True, help="Directory of original images")
    parser.add_argument("--output_dir", required=True, help="Where to save JSON outputs")
    parser.add_argument("--ref", required=True, help=".pt file produced by train_text_ref.py (learned reference)")
    parser.add_argument("--batch_size", type=int, default=64, help="CLIP inference batch size")
    args = parser.parse_args()

    convert(args)
