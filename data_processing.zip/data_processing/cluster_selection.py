import os
import json
import argparse
import numpy as np
import cv2
import random
from itertools import combinations
from PIL import Image
import networkx as nx

def boxes_touch_or_overlap(b1, b2, pad=1):
    x0a, y0a, x1a, y1a = b1
    x0b, y0b, x1b, y1b = b2
    x0a, y0a, x1a, y1a = x0a - pad, y0a - pad, x1a + pad, y1a + pad
    x0b, y0b, x1b, y1b = x0b - pad, y0b - pad, x1b + pad, y1b + pad
    return not (x1a < x0b or x1b < x0a or y1a < y0b or y1b < y0a)

def yolo_to_pixel_bbox(yolo_box, img_w, img_h):
    x_c, y_c, w, h = yolo_box
    x_c *= img_w
    y_c *= img_h
    w *= img_w
    h *= img_h
    x0 = int(round(x_c - w / 2))
    y0 = int(round(y_c - h / 2))
    x1 = int(round(x_c + w / 2))
    y1 = int(round(y_c + h / 2))
    x0 = max(x0, 0)
    y0 = max(y0, 0)
    x1 = min(x1, img_w)
    y1 = min(y1, img_h)
    return (x0, y0, x1, y1)

def cluster_humans(mask_img, bboxes):
    H, W = mask_img.shape
    person_masks = []
    for (x0, y0, x1, y1) in bboxes:
        m = np.zeros((H, W), np.uint8)
        m[y0:y1, x0:x1] = (mask_img[y0:y1, x0:x1] > 0).astype(np.uint8)
        person_masks.append(m)

    G = nx.Graph()
    G.add_nodes_from(range(len(bboxes)))
    kernel = np.ones((3, 3), np.uint8)

    for i, j in combinations(range(len(bboxes)), 2):
        if not boxes_touch_or_overlap(bboxes[i], bboxes[j], pad=1):
            continue
        dilated = cv2.dilate(person_masks[i], kernel, iterations=1)
        if np.any(dilated & person_masks[j]):
            G.add_edge(i, j)

    clusters = list(nx.connected_components(G))
    cluster_id_map = {}
    for cluster_idx, cluster in enumerate(clusters):
        for idx in cluster:
            cluster_id_map[idx] = cluster_idx
    return cluster_id_map

def choose_clusters_to_keep(cluster_id_map, min_keep=1, max_keep=None):
    all_clusters = list(set(cluster_id_map.values()))
    if not all_clusters:
        return set()
    n_clusters = len(all_clusters)
    max_keep = min(max_keep or n_clusters, n_clusters)
    min_keep = max(1, min(min_keep, max_keep))
    n_keep = random.randint(min_keep, max_keep)
    return set(random.sample(all_clusters, n_keep))

def convert_labels_to_json_files(labels_dir, masks_dir, output_dir, min_keep=1, max_keep=None):
    os.makedirs(output_dir, exist_ok=True)

    for fname in sorted(os.listdir(labels_dir)):
        if not fname.lower().endswith('.txt'):
            continue

        base = os.path.splitext(fname)[0]
        in_path = os.path.join(labels_dir, fname)
        mask_fname = base + '_mask.png'
        mask_path = os.path.join(masks_dir, mask_fname)

        if not os.path.isfile(mask_path):
            print(f"Warning: mask file {mask_fname} not found for label {fname}")
            continue

        mask_img = np.array(Image.open(mask_path).convert('L'))
        mask_img = (mask_img > 0).astype(np.uint8) * 255
        H, W = mask_img.shape

        yolo_boxes = []
        with open(in_path, 'r') as f:
            for idx, line in enumerate(f):
                parts = line.strip().split()
                if len(parts) != 5:
                    print(f"Skipping malformed line {idx} in {fname}: {line!r}")
                    continue
                cls, x, y, w, h = map(float, parts)
                yolo_boxes.append((x, y, w, h))

        if not yolo_boxes:
            print(f"No valid people in {fname}")
            continue

        pixel_bboxes = [yolo_to_pixel_bbox(box, W, H) for box in yolo_boxes]
        cluster_id_map = cluster_humans(mask_img, pixel_bboxes)
        keep_clusters = choose_clusters_to_keep(cluster_id_map, min_keep=min_keep, max_keep=max_keep)

        objects = []
        for idx, box in enumerate(yolo_boxes):
            cid = int(cluster_id_map[idx])
            objects.append({
                "id": idx,
                "class": 0,
                "bbox": list(map(float, box)),
                "cluster_id": cid,
                "keep": bool(cid in keep_clusters)
            })

        data = {
            "image_id": base,
            "objects": objects
        }

        out_path = os.path.join(output_dir, base + '.json')
        with open(out_path, 'w') as out_f:
            json.dump(data, out_f, indent=2)
        print(f"Wrote {len(objects)} objects with clusters to {out_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Convert YOLO labels + masks to per-image JSON with clusters and keep flags")
    parser.add_argument("--labels_dir", type=str, required=True, help="Directory with YOLO .txt label files")
    parser.add_argument("--masks_dir", type=str, required=True, help="Directory with binary mask images (suffix _mask.png)")
    parser.add_argument("--output_dir", type=str, required=True, help="Where to write per-image .json files")
    parser.add_argument("--min_keep", type=int, default=1, help="Minimum clusters to keep per image (default: 1)")
    parser.add_argument("--max_keep", type=int, default=None, help="Maximum clusters to keep per image (default: all)")
    args = parser.parse_args()

    convert_labels_to_json_files(
        args.labels_dir,
        args.masks_dir,
        args.output_dir,
        min_keep=args.min_keep,
        max_keep=args.max_keep
    )
