import os
import shutil

# --- 1. CONFIGURATION ---
# Set the path to your original dataset folder
SOURCE_DATASET_DIR = '/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_update2'  # Change this to the name of your dataset folder

# Set the path where you want to save the split dataset
OUTPUT_DIR = '/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_update2_sequential'

# Number of parts to split the dataset into
NUM_PARTS = 4
# --------------------------

def split_dataset_sequentially():
    """
    Splits a dataset of images, labels, and masks sequentially into a specified number of parts.
    """
    # Define the source subdirectories
    source_images_dir = os.path.join(SOURCE_DATASET_DIR, 'images')
    source_labels_dir = os.path.join(SOURCE_DATASET_DIR, 'labels')
    source_masks_dir = os.path.join(SOURCE_DATASET_DIR, 'masks')

    # --- 2. GET AND SORT FILE LIST ---
    # Get the list of all image files and sort them alphabetically
    try:
        # Sorting ensures a consistent, sequential order
        all_image_files = sorted([f for f in os.listdir(source_images_dir) if f.endswith('.jpg')])
    except FileNotFoundError:
        print(f"Error: The directory '{source_images_dir}' was not found.")
        print("Please make sure the SOURCE_DATASET_DIR is set correctly.")
        return

    # --- 3. CALCULATE SPLIT SIZE ---
    total_files = len(all_image_files)
    if total_files == 0:
        print(f"Error: No .jpg files found in '{source_images_dir}'.")
        return
        
    files_per_part = total_files // NUM_PARTS
    print(f"Total files: {total_files}")
    print(f"Splitting into {NUM_PARTS} parts, with {files_per_part} file sets each.")

    # --- 4. CREATE DIRECTORIES AND COPY FILES ---
    for i in range(NUM_PARTS):
        part_number = i + 1
        part_name = f'Part_{part_number}'
        print(f"\nProcessing {part_name}...")

        # Define destination directories for this part
        dest_part_dir = os.path.join(OUTPUT_DIR, part_name)
        dest_images_dir = os.path.join(dest_part_dir, 'images')
        dest_labels_dir = os.path.join(dest_part_dir, 'labels')
        dest_masks_dir = os.path.join(dest_part_dir, 'masks')

        # Create the directories if they don't exist
        os.makedirs(dest_images_dir, exist_ok=True)
        os.makedirs(dest_labels_dir, exist_ok=True)
        os.makedirs(dest_masks_dir, exist_ok=True)

        # Determine the chunk of files for the current part
        start_index = i * files_per_part
        end_index = (i + 1) * files_per_part if i < NUM_PARTS - 1 else total_files
        current_files_chunk = all_image_files[start_index:end_index]

        # Copy the corresponding image, label, and mask files
        for image_filename in current_files_chunk:
            base_name = os.path.splitext(image_filename)[0]
            label_filename = f"{base_name}.txt"
            mask_filename = f"{base_name}_mask.png"

            # Copy files, checking for existence first
            for src_dir, dest_dir, filename in [
                (source_images_dir, dest_images_dir, image_filename),
                (source_labels_dir, dest_labels_dir, label_filename),
                (source_masks_dir, dest_masks_dir, mask_filename),
            ]:
                src_path = os.path.join(src_dir, filename)
                if os.path.exists(src_path):
                    shutil.copy(src_path, dest_dir)
                else:
                    print(f"  - Warning: File not found and was skipped: {src_path}")

        print(f"-> Finished copying {len(current_files_chunk)} sets of files to {part_name}.")

    print("\n✅ Dataset splitting complete!")


if __name__ == '__main__':
    split_dataset_sequentially()
