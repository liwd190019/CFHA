import os
import random
import shutil

# Root folder
root = "/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/manipal_update3_removal"

# Source folders
img_src = os.path.join(root, "images")
lbl_src = os.path.join(root, "labels")

# Output folders
out_train_img = os.path.join(root, "train/images")
out_train_lbl = os.path.join(root, "train/labels")
out_val_img = os.path.join(root, "val/images")
out_val_lbl = os.path.join(root, "val/labels")

# Create output directories
for d in [out_train_img, out_train_lbl, out_val_img, out_val_lbl]:
    os.makedirs(d, exist_ok=True)

# Get all image files
images = [f for f in os.listdir(img_src) if f.endswith(".png")]
images.sort()

# Randomly select 40 for validation
random.seed(42)  # for reproducibility
val_images = set(random.sample(images, 40))
train_images = [f for f in images if f not in val_images]

# Function to copy paired image and label
def copy_pair(filenames, dest_img, dest_lbl):
    for img_file in filenames:
        lbl_file = img_file.replace(".png", ".txt")
        shutil.copy(os.path.join(img_src, img_file), os.path.join(dest_img, img_file))
        shutil.copy(os.path.join(lbl_src, lbl_file), os.path.join(dest_lbl, lbl_file))

# Copy files
copy_pair(train_images, out_train_img, out_train_lbl)
copy_pair(val_images, out_val_img, out_val_lbl)

print(f"Split complete: {len(train_images)} train, {len(val_images)} val")
