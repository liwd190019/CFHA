import os
import shutil

# Define the base directory of the original dataset
base_dir = '/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/test-rm-low-light'

# Define the new base directory where the subsampled dataset will be saved
# Change this to your desired output path
new_base_dir = '/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_yolo_train/test-rm-low-light_subsampled'

# Paths to original images and labels
images_dir = os.path.join(base_dir, 'images')
labels_dir = os.path.join(base_dir, 'labels')

# Create new directories for subsampled images and labels
new_images_dir = os.path.join(new_base_dir, 'images')
new_labels_dir = os.path.join(new_base_dir, 'labels')
os.makedirs(new_images_dir, exist_ok=True)
os.makedirs(new_labels_dir, exist_ok=True)

# Get sorted list of image files (assuming all are .png)
image_files = sorted([f for f in os.listdir(images_dir) if f.endswith('.png')])

# Select every 5th image starting from the first (index 0, 5, 10, ...)
for i in range(0, len(image_files), 5):
    img_file = image_files[i]
    label_file = img_file.replace('.png', '.txt')
    
    # Original paths
    orig_img_path = os.path.join(images_dir, img_file)
    orig_label_path = os.path.join(labels_dir, label_file)
    
    # Check if the label file exists
    if os.path.exists(orig_label_path):
        # New paths
        new_img_path = os.path.join(new_images_dir, img_file)
        new_label_path = os.path.join(new_labels_dir, label_file)
        
        # Copy files
        shutil.copy(orig_img_path, new_img_path)
        shutil.copy(orig_label_path, new_label_path)
    else:
        print(f"Warning: Label file {label_file} not found for image {img_file}. Skipping.")

print(f"Subsampling complete. {len(image_files) // 5 + (1 if len(image_files) % 5 > 0 else 0)} files copied to {new_base_dir}")