import os
import shutil

# --- 1. CONFIGURATION ---

# IMPORTANT: Set this to the path of the directory that contains your "Part_1", "Part_2", etc. folders.
# For example: 'dataset_split_sequential'
SOURCE_BASE_DIR = '/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_update2_sequential'

# Set the final destination path where you want the combined dataset.
DESTINATION_DIR = '/scratch/qingqu_root/qingqu1/wdli/domain_adaptation/CACTIF/data/manipal_update3_removal'

# The names of the source subfolders within each Part.
SOURCE_LABELS_FOLDER = 'labels_kept'
SOURCE_IMAGES_FOLDER = 'pasted_image_update'

# The names you want for the final aggregated subfolders.
DEST_LABELS_FOLDER = 'labels'
DEST_IMAGES_FOLDER = 'images'

# The number of parts you want to aggregate.
NUM_PARTS = 4


# --- 2. AGGREGATION SCRIPT ---

def aggregate_files():
    """
    Aggregates processed files from split part folders back into a single dataset.
    """
    print("🚀 Starting aggregation process...")

    # Create the final destination folders ('images' and 'labels')
    dest_labels_path = os.path.join(DESTINATION_DIR, DEST_LABELS_FOLDER)
    dest_images_path = os.path.join(DESTINATION_DIR, DEST_IMAGES_FOLDER)
    os.makedirs(dest_labels_path, exist_ok=True)
    os.makedirs(dest_images_path, exist_ok=True)

    total_labels_copied = 0
    total_images_copied = 0

    # Loop through each "Part" directory
    for i in range(1, NUM_PARTS + 1):
        part_name = f'Part_{i}'
        part_path = os.path.join(SOURCE_BASE_DIR, part_name)
        print(f"\n--- Processing {part_name} ---")

        if not os.path.isdir(part_path):
            print(f"⚠️ Warning: Directory not found, skipping: {part_path}")
            continue

        # --- Aggregate Labels ---
        source_labels_dir = os.path.join(part_path, SOURCE_LABELS_FOLDER)
        if os.path.isdir(source_labels_dir):
            labels = os.listdir(source_labels_dir)
            for filename in labels:
                src_file = os.path.join(source_labels_dir, filename)
                shutil.copy2(src_file, dest_labels_path) # copy2 preserves metadata
            total_labels_copied += len(labels)
            print(f"Copied {len(labels)} files from {SOURCE_LABELS_FOLDER}")
        else:
            print(f"⚠️ Warning: Label directory not found, skipping: {source_labels_dir}")

        # --- Aggregate Images ---
        source_images_dir = os.path.join(part_path, SOURCE_IMAGES_FOLDER)
        if os.path.isdir(source_images_dir):
            images = os.listdir(source_images_dir)
            for filename in images:
                src_file = os.path.join(source_images_dir, filename)
                shutil.copy2(src_file, dest_images_path)
            total_images_copied += len(images)
            print(f"Copied {len(images)} files from {SOURCE_IMAGES_FOLDER}")
        else:
            print(f"⚠️ Warning: Image directory not found, skipping: {source_images_dir}")

    print("\n--- Aggregation Summary ---")
    print(f"Total labels copied: {total_labels_copied}")
    print(f"Total images copied: {total_images_copied}")
    print(f"✅ Aggregation complete! Files are located in {DESTINATION_DIR}")


if __name__ == '__main__':
    aggregate_files()