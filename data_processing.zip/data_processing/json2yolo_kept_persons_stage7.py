#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convert Stage-3/4 JSONs to YOLO .txt labels, keeping only persons in kept clusters.

Input JSON (per image):
{
  "image_id": "<base>",
  "objects": [
    {"id": 0, "class": 0, "bbox": [x,y,w,h], "cluster_id": 2, "keep_final": true, ...},
    ...
  ],
  "clusters": [                                # optional (preferred)
    {"cluster_id": 2, "kept": true, ...},
    ...
  ]
}

Output:
  <labels_out>/<base>.txt
    Lines: "<person_cls> x y w h" (normalized floats)

If 'clusters' is present, we trust cluster['kept'].
If not, we fall back to objects with keep_final==True.
"""

import os
import json
import argparse
from tqdm import tqdm

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

def build_kept_cluster_set(data):
    """Return a set of cluster_ids that are kept. If clusters missing, return None."""
    clusters = data.get("clusters", None)
    if clusters is None:
        return None
    kept = set()
    for c in clusters:
        cid = int(c.get("cluster_id", -1))
        # accept either 'kept' or 'keep'
        flag = c.get("kept", None)
        if flag is None:
            flag = c.get("keep", False)
        if bool(flag):
            kept.add(cid)
    return kept

def clamp01(v):
    return max(0.0, min(1.0, float(v)))

def format_yolo_line(cls, bbox_norm):
    x, y, w, h = [clamp01(t) for t in bbox_norm]
    return f"{int(cls)} {x:.6f} {y:.6f} {w:.6f} {h:.6f}"

def convert(json_dir, labels_out, person_cls=0, skip_empty=False):
    os.makedirs(labels_out, exist_ok=True)
    files = sorted([f for f in os.listdir(json_dir) if f.endswith(".json")])

    for fname in tqdm(files, desc="Converting to YOLO"):
        base = os.path.splitext(fname)[0]
        path = os.path.join(json_dir, fname)
        data = load_json(path)

        objs = data.get("objects", [])
        kept_clusters = build_kept_cluster_set(data)  # set or None

        lines = []
        for o in objs:
            # filter to person class id
            if int(o.get("class", -1)) != person_cls:
                continue

            # decide kept
            if kept_clusters is not None:
                cid = int(o.get("cluster_id", -1))
                kept = (cid in kept_clusters)
            else:
                kept = bool(o.get("keep_final", False))

            if not kept:
                continue

            bbox = o.get("bbox", None)
            if not bbox or len(bbox) != 4:
                continue

            lines.append(format_yolo_line(person_cls, bbox))

        out_path = os.path.join(labels_out, base + ".txt")

        if not lines and skip_empty:
            # Don’t write a file at all
            continue

        # Write file (possibly empty; many YOLO tools expect a .txt to exist)
        with open(out_path, "w") as f:
            for ln in lines:
                f.write(ln + "\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json_dir", required=True, help="Folder of Stage-3/4 JSON files")
    ap.add_argument("--labels_out", required=True, help="Output folder for YOLO .txt labels")
    ap.add_argument("--person_cls", type=int, default=0, help="Numeric class id for 'person' (default 0)")
    ap.add_argument("--skip_empty", action="store_true",
                    help="If set, do not create .txt when no kept persons exist")
    args = ap.parse_args()

    convert(args.json_dir, args.labels_out, person_cls=args.person_cls, skip_empty=args.skip_empty)

if __name__ == "__main__":
    main()
