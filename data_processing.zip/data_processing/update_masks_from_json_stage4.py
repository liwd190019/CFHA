# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
# """
# Stage 4 (center-color version): Update masks by cluster-level kept/keep flags.

# For each JSON and its corresponding RGB instance mask "<base>_mask.png":
#   - Determine which clusters are kept via data["clusters"][*]["kept"] (or "keep");
#     fall back to objects' keep_final if clusters are absent.
#   - For each object (bbox in YOLO normalized coords):
#       * Find the center pixel color within the bbox in the RGB instance mask.
#       * If center is black, search a small neighborhood for the nearest non-black pixel color.
#       * Build an instance mask by matching that color across the mask, then constrain to bbox.
#   - If the object's cluster is kept, set those pixels to 255 (white) in the output mask,
#     otherwise set/leave them as 0 (black).
#   - Save a single-channel B&W mask to output_dir as "<base>_mask.png".
# """

# import os
# import json
# import argparse
# from typing import Optional, Tuple

# import numpy as np
# from PIL import Image
# from tqdm import tqdm

# # ----------------- Helpers -----------------

# def yolo_to_pixel_bbox(yolo_box, img_w, img_h):
#     """Convert YOLO (x_c, y_c, w, h) in [0,1] to pixel (x0, y0, x1, y1), clamped."""
#     x_c, y_c, w, h = yolo_box
#     x_c *= img_w; y_c *= img_h
#     w *= img_w;  h *= img_h
#     x0 = int(round(x_c - w / 2))
#     y0 = int(round(y_c - h / 2))
#     x1 = int(round(x_c + w / 2))
#     y1 = int(round(y_c + h / 2))
#     return max(0, x0), max(0, y0), min(img_w, x1), min(img_h, y1)

# def clamp(v, lo, hi):
#     return max(lo, min(hi, v))

# def get_center_color(mask_rgb: np.ndarray, bbox: Tuple[int,int,int,int],
#                      search_radius: int = 3) -> Optional[Tuple[int,int,int]]:
#     """
#     Returns the (R,G,B) color at the bbox center; if it's black (0,0,0),
#     search up to `search_radius` pixels around the center (inside bbox)
#     for the nearest non-black pixel. Returns None if none found.
#     """
#     H, W, _ = mask_rgb.shape
#     x0, y0, x1, y1 = bbox
#     if x1 <= x0 or y1 <= y0:
#         return None

#     cx = (x0 + x1) // 2
#     cy = (y0 + y1) // 2
#     cx = clamp(cx, 0, W - 1)
#     cy = clamp(cy, 0, H - 1)

#     c = tuple(int(v) for v in mask_rgb[cy, cx])
#     if c != (0, 0, 0):
#         return c

#     # Search nearest non-black pixel within bbox
#     for r in range(1, max(1, int(search_radius)) + 1):
#         y_min = clamp(cy - r, y0, y1 - 1)
#         y_max = clamp(cy + r, y0, y1 - 1)
#         x_min = clamp(cx - r, x0, x1 - 1)
#         x_max = clamp(cx + r, x0, x1 - 1)
#         # Check border ring at distance r (4-connected + diagonals)
#         for y in range(y_min, y_max + 1):
#             for x in (x_min, x_max):
#                 col = tuple(int(v) for v in mask_rgb[y, x])
#                 if col != (0, 0, 0):
#                     return col
#         for x in range(x_min, x_max + 1):
#             for y in (y_min, y_max):
#                 col = tuple(int(v) for v in mask_rgb[y, x])
#                 if col != (0, 0, 0):
#                     return col

#     return None  # not found

# def extract_person_mask_center(mask_rgb: np.ndarray, bbox: Tuple[int,int,int,int],
#                                search_radius: int = 3) -> np.ndarray:
#     """
#     Build a BINARY mask (H,W) uint8 by matching the center (or nearest) color
#     within `bbox`, then constrain the match to the bbox to avoid leakage.
#     Returns all-zero mask if no valid color is found.
#     """
#     H, W = mask_rgb.shape[:2]
#     x0, y0, x1, y1 = bbox
#     if x1 <= x0 or y1 <= y0:
#         return np.zeros((H, W), dtype=np.uint8)

#     color = get_center_color(mask_rgb, bbox, search_radius=search_radius)
#     if color is None:
#         # No non-black near center inside bbox
#         return np.zeros((H, W), dtype=np.uint8)

#     # Full-image equality match to that color
#     match = (mask_rgb[:, :, 0] == color[0]) & \
#             (mask_rgb[:, :, 1] == color[1]) & \
#             (mask_rgb[:, :, 2] == color[2])

#     out = np.zeros((H, W), dtype=np.uint8)
#     out[y0:y1, x0:x1] = (match[y0:y1, x0:x1].astype(np.uint8) * 255)
#     return out

# def build_cluster_kept_map(data):
#     """
#     Prefer cluster-level 'kept' (or 'keep') in data['clusters'].
#     Fallback: OR over objects' keep_final per cluster if clusters missing.
#     Returns {cluster_id: bool}.
#     """
#     kept_map = {}
#     clusters = data.get("clusters", None)
#     if clusters is not None:
#         for c in clusters:
#             cid = int(c.get("cluster_id", -1))
#             kept = c.get("kept", None)
#             if kept is None:
#                 kept = c.get("keep", False)
#             kept_map[cid] = bool(kept)
#         return kept_map

#     # Fallback
#     for o in data.get("objects", []):
#         cid = int(o.get("cluster_id", -1))
#         kept_map[cid] = kept_map.get(cid, False) or bool(o.get("keep_final", False))
#     return kept_map

# # ----------------- Core -----------------

# def update_masks_stage4_center(masks_dir, json_dir, output_dir, search_radius: int = 3):
#     os.makedirs(output_dir, exist_ok=True)
#     files = sorted([f for f in os.listdir(json_dir) if f.endswith(".json")])

#     for fname in tqdm(files, desc="Stage-4 (center-color) updating masks"):
#         base = os.path.splitext(fname)[0]
#         json_path = os.path.join(json_dir, fname)
#         mask_path = os.path.join(masks_dir, base + "_mask.png")

#         if not os.path.exists(mask_path):
#             print(f"[WARN] Mask not found: {mask_path}")
#             continue

#         with open(json_path, "r") as f:
#             data = json.load(f)

#         objects = data.get("objects", [])
#         mask_rgb = np.array(Image.open(mask_path).convert("RGB"))
#         H, W = mask_rgb.shape[:2]

#         # Prepare output (B&W) mask
#         out_mask = np.zeros((H, W), dtype=np.uint8)

#         # Cluster kept map
#         cluster_kept = build_cluster_kept_map(data)

#         # Paint per object according to its cluster kept flag
#         # for o in objects:
#         #     cid = int(o.get("cluster_id", -1))
#         #     kept = bool(cluster_kept.get(cid, False))
#         #     bbox = o.get("bbox", None)
#         #     if bbox is None or len(bbox) != 4:
#         #         continue

#         #     x0, y0, x1, y1 = yolo_to_pixel_bbox(bbox, W, H)
#         #     inst_mask = extract_person_mask_center(mask_rgb, (x0, y0, x1, y1),
#         #                                            search_radius=search_radius)
#         #     if kept:
#         #         out_mask[inst_mask > 0] = 255  # kept clusters -> white
#         #     else:
#         #         out_mask[inst_mask > 0] = 0    # not-kept clusters -> black (already 0)
        
#         # Paint per object according to its cluster kept flag
#         for o in objects:
#             cid = int(o.get("cluster_id", -1))
#             kept = bool(cluster_kept.get(cid, False))
#             bbox = o.get("bbox", None)
#             if bbox is None or len(bbox) != 4:
#                 continue

#             x0, y0, x1, y1 = yolo_to_pixel_bbox(bbox, W, H)

#             if kept:
#                 # NEW: whiten the entire bbox region (kept person)
#                 out_mask[y0:y1, x0:x1] = 255
#             else:
#                 # NOTE: leave untouched (already 0) to avoid clobbering overlapping kept regions
#                 pass


#         # Save single-channel B&W mask
#         Image.fromarray(out_mask).save(os.path.join(output_dir, base + "_mask.png"))

# # ----------------- CLI -----------------

# def main():
#     ap = argparse.ArgumentParser()
#     ap.add_argument("--masks_dir", required=True, help="Directory of original RGB instance masks")
#     ap.add_argument("--json_dir", required=True, help="Directory of JSON files (with cluster kept/keep or keep_final)")
#     ap.add_argument("--output_dir", required=True, help="Directory to save updated B&W masks")
#     ap.add_argument("--search_radius", type=int, default=3,
#                     help="Max Manhattan radius to search for nearest non-black color if center is black")
#     args = ap.parse_args()

#     update_masks_stage4_center(args.masks_dir, args.json_dir, args.output_dir,
#                                search_radius=args.search_radius)

# if __name__ == "__main__":
#     main()



#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage 4 (center-color version): Update masks by cluster-level kept/keep flags.

For each JSON and its corresponding RGB instance mask "<base>_mask.png":
  - Determine which clusters are kept via data["clusters"][*]["kept"] (or "keep");
    fall back to objects' keep_final if clusters are absent.
  - For each object (bbox in YOLO normalized coords):
      * Find the center pixel color within the bbox in the RGB instance mask.
      * If center is black, search a small neighborhood for the nearest non-black pixel color.
      * Build an instance mask by matching that color across the mask, then constrain to bbox.
  - If the object's cluster is kept, set those pixels to 255 (white) in the output mask,
    otherwise set/leave them as 0 (black).
  - Save a single-channel B&W mask to output_dir as "<base>_mask.png".
"""

import os
import json
import argparse
from typing import Optional, Tuple

import numpy as np
from PIL import Image
from tqdm import tqdm

# ----------------- Helpers -----------------

def yolo_to_pixel_bbox(yolo_box, img_w, img_h):
    """Convert YOLO (x_c, y_c, w, h) in [0,1] to pixel (x0, y0, x1, y1), clamped."""
    x_c, y_c, w, h = yolo_box
    x_c *= img_w; y_c *= img_h
    w *= img_w;  h *= img_h
    x0 = int(round(x_c - w / 2))
    y0 = int(round(y_c - h / 2))
    x1 = int(round(x_c + w / 2))
    y1 = int(round(y_c + h / 2))
    return max(0, x0), max(0, y0), min(img_w, x1), min(img_h, y1)

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def get_center_color(mask_rgb: np.ndarray, bbox: Tuple[int,int,int,int],
                     search_radius: int = 3) -> Optional[Tuple[int,int,int]]:
    """
    Returns the (R,G,B) color at the bbox center; if it's black (0,0,0),
    search up to `search_radius` pixels around the center (inside bbox)
    for the nearest non-black pixel. Returns None if none found.
    """
    H, W, _ = mask_rgb.shape
    x0, y0, x1, y1 = bbox
    if x1 <= x0 or y1 <= y0:
        return None

    cx = (x0 + x1) // 2
    cy = (y0 + y1) // 2
    cx = clamp(cx, 0, W - 1)
    cy = clamp(cy, 0, H - 1)

    c = tuple(int(v) for v in mask_rgb[cy, cx])
    if c != (0, 0, 0):
        return c

    # Search nearest non-black pixel within bbox
    for r in range(1, max(1, int(search_radius)) + 1):
        y_min = clamp(cy - r, y0, y1 - 1)
        y_max = clamp(cy + r, y0, y1 - 1)
        x_min = clamp(cx - r, x0, x1 - 1)
        x_max = clamp(cx + r, x0, x1 - 1)
        # Check border ring at distance r (4-connected + diagonals)
        for y in range(y_min, y_max + 1):
            for x in (x_min, x_max):
                col = tuple(int(v) for v in mask_rgb[y, x])
                if col != (0, 0, 0):
                    return col
        for x in range(x_min, x_max + 1):
            for y in (y_min, y_max):
                col = tuple(int(v) for v in mask_rgb[y, x])
                if col != (0, 0, 0):
                    return col

    return None  # not found

def extract_person_mask_center(mask_rgb: np.ndarray, bbox: Tuple[int,int,int,int],
                               search_radius: int = 3) -> np.ndarray:
    """
    Build a BINARY mask (H,W) uint8 by matching the center (or nearest) color
    within `bbox`, then constrain the match to the bbox to avoid leakage.
    Returns all-zero mask if no valid color is found.
    """
    H, W = mask_rgb.shape[:2]
    x0, y0, x1, y1 = bbox
    if x1 <= x0 or y1 <= y0:
        return np.zeros((H, W), dtype=np.uint8)

    color = get_center_color(mask_rgb, bbox, search_radius=search_radius)
    if color is None:
        # No non-black near center inside bbox
        return np.zeros((H, W), dtype=np.uint8)

    # Full-image equality match to that color
    match = (mask_rgb[:, :, 0] == color[0]) & \
            (mask_rgb[:, :, 1] == color[1]) & \
            (mask_rgb[:, :, 2] == color[2])

    out = np.zeros((H, W), dtype=np.uint8)
    out[y0:y1, x0:x1] = (match[y0:y1, x0:x1].astype(np.uint8) * 255)
    return out

def build_cluster_kept_map(data):
    """
    Prefer cluster-level 'kept' (or 'keep') in data['clusters'].
    Fallback: OR over objects' keep_final per cluster if clusters missing.
    Returns {cluster_id: bool}.
    """
    kept_map = {}
    clusters = data.get("clusters", None)
    if clusters is not None:
        for c in clusters:
            cid = int(c.get("cluster_id", -1))
            kept = c.get("kept", None)
            if kept is None:
                kept = c.get("keep", False)
            kept_map[cid] = bool(kept)
        return kept_map

    # Fallback
    for o in data.get("objects", []):
        cid = int(o.get("cluster_id", -1))
        kept_map[cid] = kept_map.get(cid, False) or bool(o.get("keep_final", False))
    return kept_map

# ----------------- Core -----------------

def update_masks_stage4_center(masks_dir, json_dir, output_dir, search_radius: int = 3):
    os.makedirs(output_dir, exist_ok=True)
    files = sorted([f for f in os.listdir(json_dir) if f.endswith(".json")])

    for fname in tqdm(files, desc="Stage-4 (center-color) updating masks"):
        base = os.path.splitext(fname)[0]
        json_path = os.path.join(json_dir, fname)
        mask_path = os.path.join(masks_dir, base + "_mask.png")

        if not os.path.exists(mask_path):
            print(f"[WARN] Mask not found: {mask_path}")
            continue

        with open(json_path, "r") as f:
            data = json.load(f)

        objects = data.get("objects", [])
        mask_rgb = np.array(Image.open(mask_path).convert("RGB"))
        H, W = mask_rgb.shape[:2]

        # Prepare output (B&W) mask
        out_mask = np.zeros((H, W), dtype=np.uint8)

        # Cluster kept map
        cluster_kept = build_cluster_kept_map(data)

        # Paint per object according to its cluster kept flag
        for o in objects:
            cid = int(o.get("cluster_id", -1))
            kept = bool(cluster_kept.get(cid, False))
            bbox = o.get("bbox", None)
            if bbox is None or len(bbox) != 4:
                continue

            x0, y0, x1, y1 = yolo_to_pixel_bbox(bbox, W, H)
            inst_mask = extract_person_mask_center(mask_rgb, (x0, y0, x1, y1),
                                                  search_radius=search_radius)
            if kept:
                out_mask[inst_mask > 0] = 255  # kept clusters -> white
            # else: leave as black (already 0)

        # Save single-channel B&W mask
        Image.fromarray(out_mask).save(os.path.join(output_dir, base + "_mask.png"))

# ----------------- CLI -----------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--masks_dir", required=True, help="Directory of original RGB instance masks")
    ap.add_argument("--json_dir", required=True, help="Directory of JSON files (with cluster kept/keep or keep_final)")
    ap.add_argument("--output_dir", required=True, help="Directory to save updated B&W masks")
    ap.add_argument("--search_radius", type=int, default=3,
                    help="Max Manhattan radius to search for nearest non-black color if center is black")
    args = ap.parse_args()

    update_masks_stage4_center(args.masks_dir, args.json_dir, args.output_dir,
                               search_radius=args.search_radius)

if __name__ == "__main__":
    main()
