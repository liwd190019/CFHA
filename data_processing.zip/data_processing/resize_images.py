import os
import sys
from PIL import Image

def resize_images_in_folder(folder_path, target_width=1280, target_height=720):
    if not os.path.isdir(folder_path):
        print(f"Error: Folder '{folder_path}' not found.")
        return

    target_size = (int(target_width), int(target_height))
    exts = ('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff')

    print(f"Scanning folder: {folder_path}")
    print(f"Target size: {target_size[0]}x{target_size[1]}\n")

    for filename in os.listdir(folder_path):
        if not filename.lower().endswith(exts):
            continue
        file_path = os.path.join(folder_path, filename)
        try:
            with Image.open(file_path) as img:
                if img.size == target_size:
                    print(f"Skipping '{filename}', already correct size.")
                    continue

                print(f"Resizing '{filename}' from {img.size[0]}x{img.size[1]}...")
                # Use LANCZOS if available; fallback otherwise
                resample = getattr(Image, "Resampling", Image).LANCZOS
                out = img.resize(target_size, resample)

                # Convert paletted/LA/CMYK to RGB to avoid save issues
                if out.mode not in ("RGB", "RGBA", "L"):
                    out = out.convert("RGB")

                out.save(file_path)
        except Exception as e:
            print(f"Could not process '{filename}'. Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python resize_images.py <path_to_folder> <target_width> <target_height>")
    else:
        folder = sys.argv[1]
        width = int(sys.argv[2])
        height = int(sys.argv[3])
        resize_images_in_folder(folder, width, height)
        print("\nDone!")
