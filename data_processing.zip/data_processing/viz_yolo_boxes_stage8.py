#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import argparse
from typing import List, Tuple, Optional

import cv2
import numpy as np
from tqdm import tqdm

IMG_EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")

def find_image_path(images_dir: str, base: str) -> Optional[str]:
    for ext in IMG_EXTS:
        p = os.path.join(images_dir, base + ext)
        if os.path.exists(p):
            return p
    return None

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def yolo_to_xyxy(b: Tuple[float,float,float,float], W: int, H: int) -> Tuple[int,int,int,int]:
    """(xc,yc,w,h) in [0,1] -> pixel (x0,y0,x1,y1) clipped to image."""
    xc, yc, w, h = b
    x0 = int(round((xc - w / 2) * W))
    y0 = int(round((yc - h / 2) * H))
    x1 = int(round((xc + w / 2) * W))
    y1 = int(round((yc + h / 2) * H))
    return clamp(x0, 0, W-1), clamp(y0, 0, H-1), clamp(x1, 0, W-1), clamp(y1, 0, H-1)

def read_names(names_path: Optional[str]) -> List[str]:
    if not names_path:
        return []
    with open(names_path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f.readlines()]
    return [ln for ln in lines if ln]

def parse_label_line(ln: str) -> Optional[Tuple[int, float, float, float, float]]:
    parts = ln.strip().split()
    if len(parts) < 5:
        return None
    try:
        cls = int(float(parts[0]))
        xc, yc, w, h = map(float, parts[1:5])
        return cls, xc, yc, w, h
    except Exception:
        return None

def draw_box(img: np.ndarray,
             x0: int, y0: int, x1: int, y1: int,
             color=(0, 255, 0), thickness=2,
             label: Optional[str]=None):
    cv2.rectangle(img, (x0, y0), (x1, y1), color, thickness)
    if label is not None:
        # Text background
        (tw, th), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        bx0, by0 = x0, max(0, y0 - th - baseline - 2)
        bx1, by1 = x0 + tw + 6, y0
        cv2.rectangle(img, (bx0, by0), (bx1, by1), color, -1)
        cv2.putText(img, label, (x0 + 3, y0 - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (0, 0, 0), 1, cv2.LINE_AA)

def visualize(images_dir: str,
              labels_dir: str,
              output_dir: str,
              names_path: Optional[str],
              thickness: int,
              color: Tuple[int,int,int]):
    os.makedirs(output_dir, exist_ok=True)
    class_names = read_names(names_path)

    label_files = sorted([f for f in os.listdir(labels_dir) if f.endswith(".txt")])
    for lf in tqdm(label_files, desc="Drawing boxes"):
        base = os.path.splitext(lf)[0]
        img_path = find_image_path(images_dir, base)
        if img_path is None:
            print(f"[WARN] image not found for {base}")
            continue

        img = cv2.imread(img_path, cv2.IMREAD_COLOR)
        if img is None:
            print(f"[WARN] failed to load image: {img_path}")
            continue
        H, W = img.shape[:2]

        with open(os.path.join(labels_dir, lf), "r", encoding="utf-8") as f:
            lines = [ln for ln in f.readlines() if ln.strip()]

        for ln in lines:
            parsed = parse_label_line(ln)
            if parsed is None:
                continue
            cls, xc, yc, w, h = parsed
            # Clamp normalized values to [0,1] to be safe
            xc, yc, w, h = [clamp(v, 0.0, 1.0) for v in (xc, yc, w, h)]
            x0, y0, x1, y1 = yolo_to_xyxy((xc, yc, w, h), W, H)
            name = None
            if 0 <= cls < len(class_names):
                name = class_names[cls]
            label = f"{cls}" if name is None else f"{cls}:{name}"
            draw_box(img, x0, y0, x1, y1, color=color, thickness=thickness, label=label)

        out_ext = ".png"  # save losslessly
        out_path = os.path.join(output_dir, base + out_ext)
        cv2.imwrite(out_path, img)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images_dir", required=True, help="Directory with RGB images")
    ap.add_argument("--labels_dir", required=True, help="Directory with YOLO .txt labels")
    ap.add_argument("--output_dir", required=True, help="Directory to save visualizations")
    ap.add_argument("--names", default=None,
                    help="Optional path to .names file (one class name per line). If omitted, only class id is shown.")
    ap.add_argument("--thickness", type=int, default=2, help="Bounding box line thickness")
    ap.add_argument("--color", type=str, default="0,255,0",
                    help="Box color as 'B,G,R' (OpenCV order). Example: '0,255,0' for green")
    args = ap.parse_args()

    try:
        b, g, r = [int(c) for c in args.color.split(",")]
        color = (b, g, r)
    except Exception:
        color = (0, 255, 0)  # default green

    visualize(args.images_dir, args.labels_dir, args.output_dir,
              names_path=args.names, thickness=args.thickness, color=color)

if __name__ == "__main__":
    main()
